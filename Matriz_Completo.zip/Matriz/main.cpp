#include <iostream>
#include "Matriz.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(){
	Matriz A(2,2,4), B(2,2,3), C(2,2,3);

 	

	
}
